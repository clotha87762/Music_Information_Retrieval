助教要跑code的話，把audio跟score-info資料夾跟其他的function跟hw3.m整個放在同一個目錄底下執行hw3.m就行了。

依照每個小題，我都用%%把每題區隔開來了，助教可以依照註解的題號來跑
(注意，要跑第六第七和進階題的話要先跑Train Dictionaty的區段)

